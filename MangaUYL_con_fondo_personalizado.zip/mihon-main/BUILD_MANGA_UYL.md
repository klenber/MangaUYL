# Compilar MangaUYL

Requisitos: JDK 21, Android SDK instalado y conexión a internet para descargar las dependencias Gradle.

Desde la raíz del proyecto:

```bash
./gradlew :app:assembleStandardDebug
```

El APK debug se genera bajo `app/build/outputs/apk/`.

Para generar una versión release firmada, configura un keystore propio y las propiedades de firma que espera `app/build.gradle.kts`. No distribuyas un APK release sin una firma controlada por ti.

El entorno donde se preparó este archivo no tenía Android SDK ni acceso al servidor de distribución de Gradle, por lo que no fue posible ejecutar la compilación aquí.
