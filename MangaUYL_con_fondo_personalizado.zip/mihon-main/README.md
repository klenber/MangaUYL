# MangaUYL

MangaUYL is an independently branded fork of [Mihon](https://github.com/mihonapp/mihon),
retaining Mihon’s Android manga-reader architecture and its existing reader, library,
source-extension, download, update, backup, and tracking implementations.

## Project status

This source tree is the initial branded fork based on Mihon 0.21.3 source. The app ID is
`app.mangauyl` and the displayed application name is `MangaUYL`. The existing Mihon
features are retained rather than reimplemented as parallel systems. Spanish resources
are included in the upstream i18n module and follow the device/app language selection.

This is not a claim that the additional UI redesigns previously discussed (large-card
catalog, new global filters, or custom reader overlay) have been implemented. Those
require separate integration and testing in this source tree.

## Building

Build the debug APK on a machine with JDK 21 and Android SDK installed:

```bash
./gradlew :app:assembleStandardDebug
```

The APK output location depends on the configured Android build variant under
`app/build/outputs/apk/`.

## Upstream and licensing

MangaUYL is based on Mihon, an open-source project. See `LICENSE` and the upstream
project’s notices for applicable license terms and attribution. MangaUYL is an
independent fork and is not an official Mihon release.
