package eu.kanade.domain.manga.model

import eu.kanade.tachiyomi.data.cache.CoverCache
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.ui.reader.setting.ReaderOrientation
import eu.kanade.tachiyomi.ui.reader.setting.ReadingMode
import kotlinx.datetime.TimeZone
import kotlinx.datetime.number
import kotlinx.datetime.toLocalDateTime
import tachiyomi.core.common.preference.TriState
import tachiyomi.core.metadata.comicinfo.ComicInfo
import tachiyomi.core.metadata.comicinfo.ComicInfoPublishingStatus
import tachiyomi.domain.chapter.model.Chapter
import tachiyomi.domain.manga.model.Manga

// TODO: move these into the domain model
val Manga.readingMode: Long
    get() = viewerFlags and ReadingMode.MASK.toLong()

val Manga.readerOrientation: Long
    get() = viewerFlags and ReaderOrientation.MASK.toLong()

fun Manga.downloadedFilter(downloadedOnly: Boolean): TriState {
    if (downloadedOnly) return TriState.ENABLED_IS
    return when (downloadedFilterRaw) {
        Manga.CHAPTER_SHOW_DOWNLOADED -> TriState.ENABLED_IS
        Manga.CHAPTER_SHOW_NOT_DOWNLOADED -> TriState.ENABLED_NOT
        else -> TriState.DISABLED
    }
}

fun Manga.chaptersFiltered(downloadedOnly: Boolean): Boolean {
    return unreadFilter != TriState.DISABLED ||
        downloadedFilter(downloadedOnly) != TriState.DISABLED ||
        bookmarkedFilter != TriState.DISABLED
}

fun Manga.toSManga(): SManga = SManga.create().also {
    it.url = url
    it.title = title
    it.artist = artist
    it.author = author
    it.description = description
    it.genre = genre.orEmpty().joinToString()
    it.status = status.toInt()
    it.thumbnail_url = thumbnailUrl
    it.initialized = initialized
    it.memo = memo
}

fun Manga.copyFrom(other: SManga): Manga {
    val author = other.author ?: author
    val artist = other.artist ?: artist
    val description = other.description ?: description
    val genres = if (other.genre != null) {
        other.getGenres()
    } else {
        genre
    }
    val thumbnailUrl = other.thumbnail_url ?: thumbnailUrl
    return this.copy(
        author = author,
        artist = artist,
        description = description,
        genre = genres,
        thumbnailUrl = thumbnailUrl,
        status = other.status.toLong(),
        updateStrategy = other.update_strategy,
        initialized = other.initialized && initialized,
        memo = other.memo,
    )
}

fun Manga.hasCustomCover(coverCache: CoverCache): Boolean {
    return coverCache.hasCustomCover(id)
}

/**
 * Creates a ComicInfo instance based on the manga and chapter metadata.
 */
fun getComicInfo(
    manga: Manga,
    chapter: Chapter,
    urls: List<String>,
    categories: List<String>?,
    sourceName: String,
): ComicInfo {
    val date = chapter.dateUpload?.toLocalDateTime(TimeZone.currentSystemDefault())

    return ComicInfo(
        title = ComicInfo.Title(chapter.name),
        series = ComicInfo.Series(manga.title),
        number = chapter.chapterNumber.takeIf { it >= 0 }?.let {
            if ((it.rem(1) == 0.0)) {
                ComicInfo.Number(it.toInt().toString())
            } else {
                ComicInfo.Number(it.toString())
            }
        },
        web = ComicInfo.Web(urls.joinToString(" ")),
        summary = manga.description?.let { ComicInfo.Summary(it) },
        writer = manga.author?.let { ComicInfo.Writer(it) },
        penciller = manga.artist?.let { ComicInfo.Penciller(it) },
        translator = chapter.scanlator?.let { ComicInfo.Translator(it) },
        genre = manga.genre?.let { ComicInfo.Genre(it.joinToString()) },
        publishingStatus = ComicInfo.PublishingStatusTachiyomi(
            ComicInfoPublishingStatus.toComicInfoValue(manga.status),
        ),
        categories = categories?.let { ComicInfo.CategoriesTachiyomi(it.joinToString()) },
        source = ComicInfo.SourceMihon(sourceName),
        inker = null,
        colorist = null,
        letterer = null,
        coverArtist = null,
        tags = null,
        year = date?.year?.let { ComicInfo.Year(it) },
        month = date?.month?.number?.let { ComicInfo.Month(it) },
        day = date?.day?.let { ComicInfo.Day(it) },
    )
}
